function operaciones(numeros){
    const media=numeros.map((numero)=>numero+numero)[3]/4;
    console.log("media ", media)

}

operaciones([1,2,3,4])