// gestor de tareas en JavaScript

class gestorTarea{

    constructor(nombre,estado,categoria,...tarea){
        this.nombre=nombre;
        this.estado=estado;
        this.tarea={nombre,estado,categoria:{categoria}};
        this.tarea.categoria.subcategoria=Array.from(...tarea);
        
    }
    
    agregar(){
        console.log("Agregando tarea:", this.tarea);
    }
    eliminar(nombre){
        if (this.tarea.nombre===nombre){
            const tarea= delete this.tarea
            
        }
        console.log("Eliminando tareas:",this.tarea);
        
    }
    actualizar(nombre){
        if (nombre===null){
            console.log("Cuando el nombre actualizar es null:",nombre??this.tarea.nombre);
            return console.log("Entonces no se actualiza y permanece el nombre anterior:", this.tarea);
        }else if (this.tarea.nombre!= nombre){
            this.tarea.nombre=nombre
            return console.log(this.tarea);
    }
}
};

const tareas= new gestorTarea("Matematicas","completado","a", [1,2,3,4]);
tareas.agregar();
tareas.eliminar("Matematicas");
const tarea1= new gestorTarea("Comunicaciòn","completado","b", [1]);
tarea1.agregar();
tarea1.actualizar("Matematicas")
tarea1.actualizar(null);