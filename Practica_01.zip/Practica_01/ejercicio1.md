´´´
class gestorTarea{

    constructor(nombre,estado,categoria,...tarea){
        this.nombre=nombre;
        this.estado=estado;
        this.tarea={nombre,estado,categoria:{categoria}};
        this.tarea.categoria.subcategoria=Array.from(...tarea);
        
    }

´´´

Aqui se implementa la estructura  de datos para manejar las tareas 
donde se implementa las tareas como objeto con las propiedaddes de nombre, estado y categoria 

´´´
this.tarea.categoria.subcategoria=Array.from(...tarea);
´´´ 

en esta linea se accede a propiedades de categoria que no esta definida en este caso es la propiedad de subcategria que se le esta asignando un array de tareas.

´´´
agregar(){
        console.log("Agregando tarea:", this.tarea);
    }
    eliminar(nombre){
        if (this.tarea.nombre===nombre){
            const tarea= delete this.tarea
            
        }
        console.log("Eliminando tareas:",this.tarea);
        
    }
    actualizar(nombre){
        if (nombre===null){
            console.log("Cuando el nombre actualizar es null:",nombre??this.tarea.nombre);
            return console.log("Entonces no se actualiza y permanece el nombre anterior:", this.tarea);
        }else if (this.tarea.nombre!= nombre){
            this.tarea.nombre=nombre
            return console.log(this.tarea);
    }
}
};

´´´


Aqui se esta implementando las operaciones CRUD de agregar, eliminar y actualizar.

´´´
    actualizar(nombre){
        if (nombre===null){
            console.log("Cuando el nombre actualizar es null:",nombre??this.tarea.nombre);
            return console.log("Entonces no se actualiza y permanece el nombre anterior:", this.tarea);
        }else if (this.tarea.nombre!= nombre){
            this.tarea.nombre=nombre
            return console.log(this.tarea);
    }
}
};
´´´
´´´
console.log("Cuando el nombre actualizar es null:",nombre??this.tarea.nombre);
´´´
aqui se aplica nullih coaescing operador 

esto se utiliza cuando se agrega un nuevo dato con null al momento de actualizar lo que hace esto se mantiene el nombre de la tarea.
como estaba.

Como se ve en las siguiente imagen:
![](imagen1.png)



